# NOVA Brain

Secure AI backend for NOVA, the Navigational Organizer & Virtual Ally.

## Cloudflare installation

Connect this GitHub repository (`tonictaddy/Nova-brain`) to the existing `nova-braintest` Worker at Cloudflare Workers & Pages > nova-braintest > Settings > Builds > Connect repository. Select the main branch and root directory `/`; set the deploy command to `npx wrangler deploy` and leave build command empty. The `name` in `wrangler.jsonc` must match the actual existing Worker name exactly. If yours is different, update that name before deploying.

In Worker Settings > Variables and Secrets, add the following as secrets (NOT plain text variables):
- GEMINI_API_KEY: your key from Google AI Studio
- NOVA_ACCESS_TOKEN: a random password-like access token you create yourself

Never put either value into GitHub or share it in chat. NOVA's GitHub Pages Settings > AI Brain screen needs the public Worker URL and access token, then Test AI. Keep in mind that a token stored in browser local storage is not robust user authentication. For personal testing only, treat this as an early prototype, and avoid placing sensitive data in memories until proper sign-in and server-side controls are added.

After linking Cloudflare, a commit to main will cause a Worker deployment when Builds is enabled. Verify the Builds tab reports success. GitHub Pages and the Cloudflare Worker are separate applications.
